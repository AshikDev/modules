<?php
return array (
  'Show warning on posting' => 'Mostrar aviso na postagem',
);
