<?php
return array (
  'Dropbox API Key' => 'Chave API Dropbox',
);
