<?php
return array (
  'Back to modules' => 'Voltar para módulos',
  'Dropbox Module Configuration' => 'Configuração de Módulo Dropbox',
  'Save' => 'Salvar',
  'The dropbox module needs active dropbox application created! Please go to this <a href="%link%" target="_blank"><strong>site</strong></a>, choose "Drop-ins app" and provide an app name to get your API key.' => 'O módulo dropbox precisa de um aplicativo dropbox ativo criado! Acesse este <a href="%link%" target="_blank"><strong>site</strong></a>, escolha "Aplicativo drop-ins" e forneça um nome de aplicativo para obter sua chave API.',
);
