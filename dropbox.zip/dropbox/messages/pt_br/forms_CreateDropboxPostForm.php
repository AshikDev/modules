<?php
return array (
  'Invalid file' => 'Arquivo inválido',
  'Message' => 'Mensagem',
);
