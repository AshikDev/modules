<?php
return array (
  'Access denied!' => 'Acesso negado!',
);
