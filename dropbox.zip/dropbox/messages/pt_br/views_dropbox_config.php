<?php
return array (
  '<strong>Dropbox</strong> settings' => 'Configurações <strong>Dropbox</strong>',
  'Submit' => 'Enviar',
);
