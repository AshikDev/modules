<?php
return array (
  'Describe your files' => 'Descreva seus arquivos',
  'Select files from dropbox' => 'Selecione arquivos para o Dropbox',
  'Submit' => 'Enviar',
);
