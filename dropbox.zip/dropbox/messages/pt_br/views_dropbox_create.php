<?php
return array (
  'Describe your files' => 'Descreva seus arquivos',
);
