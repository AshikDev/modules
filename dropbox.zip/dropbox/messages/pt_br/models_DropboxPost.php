<?php
return array (
  'Dropbox post' => 'Postagem Dropbox',
);
