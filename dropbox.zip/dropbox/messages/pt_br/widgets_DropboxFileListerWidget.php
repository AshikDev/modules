<?php
return array (
  '<strong>Attention!</strong> You are sharing private files' => '<strong>Atenção!</strong> Você está compartilhando arquivos particulares',
  'Cancel' => 'Cencelar',
  'Do not show this warning in future' => 'Não mostrar este aviso no futuro',
  'The files you want to share are private. In order to share files in your space we have generated a shared link. Everyone with the link can see the file.<br/>Are you sure you want to share?' => 'Os arquivos que você deseja compartilhar são privados. Para compartilhar arquivos em seu espaço, geramos um link compartilhado. Todos com o link podem ver o arquivo.<br/> Tem certeza de que deseja compartilhar?',
  'Yes, I\'m sure' => 'Sim. Eu tenho certeza.',
);
