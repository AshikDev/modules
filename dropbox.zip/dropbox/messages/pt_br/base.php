<?php
return array (
  'Add Dropbox files' => 'Adicionar arquivo do Dropbox',
);
