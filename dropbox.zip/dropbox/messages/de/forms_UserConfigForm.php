<?php
return array (
  'Show warning on posting' => 'Zeige Warnung beim Posten',
);
