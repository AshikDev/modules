<?php
return array (
  '<strong>Attention!</strong> You are sharing private files' => '<strong>Vorsicht!</strong> Du teilst private Dateien',
  'Cancel' => 'Abbrechen',
  'Do not show this warning in future' => 'Diese Warnung künftig nicht mehr anzeigen',
  'The files you want to share are private. In order to share files in your space we have generated a shared link. Everyone with the link can see the file.<br/>Are you sure you want to share?' => 'Die Dateien, die du teilen möchtest, sind privat. Um Dateien in deinem Space zu teilen, haben wir einen Shared Link generiert. Jeder, der den Link besitzt, kann die Dateien sehen.<br/>Bist du sicher, dass du sie teilen möchtest?',
  'Yes, I\'m sure' => 'Ja, ich bin sicher',
);
