<?php
return array (
  'Invalid file' => 'Ungültige Datei',
  'Message' => 'Nachricht',
);
