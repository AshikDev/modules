<?php
return array (
  'Sorry, the Dropbox module is not configured yet! Please get in touch with the administrator.' => 'Entschuldigung, das Dropbox-Modul ist derzeit nicht konfiguriert! Bitte trete mit dem Administrator in Verbindung.',
  'The Dropbox module is not configured yet! Please configure it <a href="%link%"><strong>here</strong></a>.' => 'Das Dropbox-Modul ist derzeit nicht konfiguriert! Bitte konfiguriere es  <a href="%link%"><strong>hier</strong></a>.',
);
