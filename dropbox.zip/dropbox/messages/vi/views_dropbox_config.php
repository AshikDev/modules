<?php
return array (
  '<strong>Dropbox</strong> settings' => '',
  'Submit' => 'Đăng cảm nghĩ',
);
