<?php
return array (
  'Describe your files' => '',
  'Select files from dropbox' => '',
  'Submit' => 'Đăng cảm nghĩ',
);
