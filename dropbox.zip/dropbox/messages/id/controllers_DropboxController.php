<?php
return array (
  'Access denied!' => 'Akses ditolak!',
);
