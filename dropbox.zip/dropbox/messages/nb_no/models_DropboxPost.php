<?php
return array (
  'Dropbox post' => 'Dropbox-innlegg',
);
