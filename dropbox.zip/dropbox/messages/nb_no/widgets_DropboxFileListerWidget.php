<?php
return array (
  '<strong>Attention!</strong> You are sharing private files' => '<strong>Hallo du!</strong> Du deler private filer!',
  'Cancel' => 'Avbryt',
  'Do not show this warning in future' => 'Ikke vis denne advarselen i fremtiden',
  'The files you want to share are private. In order to share files in your space we have generated a shared link. Everyone with the link can see the file.<br/>Are you sure you want to share?' => 'Filene du deler er private. For å dele filene med gruppen må vi generere en dele-link. Alle med linken kan da se denne filen. Er du sikker på at du vil dele?',
  'Yes, I\'m sure' => 'Ja, jeg er sikker',
);
