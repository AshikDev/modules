<?php
return array (
  'Describe your files' => 'Beskriv filer',
  'Select files from dropbox' => 'Velg filer fra Dropbox',
  'Submit' => 'Send',
);
