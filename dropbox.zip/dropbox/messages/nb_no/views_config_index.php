<?php
return array (
  'Back to modules' => 'Tilbake til moduler',
  'Dropbox Module Configuration' => 'Innstillinger for Dropbox-modulen',
  'Save' => 'Lagre',
  'The dropbox module needs active dropbox application created! Please go to this <a href="%link%" target="_blank"><strong>site</strong></a>, choose "Drop-ins app" and provide an app name to get your API key.' => 'Dropbox-modulen krever en aktiv Dropbox-applikasjon. Vennligst gå til <a href="%link%" target="_blank"><strong>denne linken</strong></a>, velg "Drop-ins app" og oppgi et applikasjonsnavn for å få en API-nøkkel.',
);
