<?php
return array (
  'Sorry, the Dropbox module is not configured yet! Please get in touch with the administrator.' => 'Beklager, Dropbox-modulen er ikke konfigurert enda. Ta kontakt med din administrator.',
  'The Dropbox module is not configured yet! Please configure it <a href="%link%"><strong>here</strong></a>.' => 'Dropbox modulen er ikke konfigurert enda. Gå <a href="%link%"><strong>hit</strong></a> for å sette den opp.',
);
