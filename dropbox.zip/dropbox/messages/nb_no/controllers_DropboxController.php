<?php
return array (
  'Access denied!' => 'Ingen adgang!',
);
