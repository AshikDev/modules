<?php
return array (
  '<strong>Dropbox</strong> settings' => '<strong>Innstillinger</strong> for Dropbox',
  'Submit' => 'Send',
);
