<?php
return array (
  'Show warning on posting' => 'Vis advarsler på innlegg',
);
