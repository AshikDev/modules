<?php
return array (
  'Invalid file' => '',
  'Message' => 'Μήνυμα',
);
