<?php
return array (
  'Access denied!' => 'Η πρόσβαση απορρίφθηκε! ',
);
