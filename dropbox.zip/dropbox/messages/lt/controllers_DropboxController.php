<?php
return array (
  'Access denied!' => 'Prieiga negalima!',
);
