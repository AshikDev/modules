<?php
return array (
  'Invalid file' => '',
  'Message' => 'Žinutė',
);
