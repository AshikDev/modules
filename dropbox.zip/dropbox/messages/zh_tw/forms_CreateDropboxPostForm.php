<?php
return array (
  'Invalid file' => '',
  'Message' => '訊息',
);
