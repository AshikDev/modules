<?php
return array (
  'Back to modules' => '',
  'Dropbox Module Configuration' => '',
  'Save' => '儲存',
  'The dropbox module needs active dropbox application created! Please go to this <a href="%link%" target="_blank"><strong>site</strong></a>, choose "Drop-ins app" and provide an app name to get your API key.' => '',
);
