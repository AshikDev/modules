<?php
return array (
  'Describe your files' => 'Popište své soubory',
  'Select files from dropbox' => 'Vyberte soubory z Dropboxu',
  'Submit' => 'Potvrdit',
);
