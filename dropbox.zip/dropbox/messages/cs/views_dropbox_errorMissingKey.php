<?php
return array (
  'Sorry, the Dropbox module is not configured yet! Please get in touch with the administrator.' => 'Omlouváme se, ale ještě není nastaven. Napište prosím administrátorovi.',
  'The Dropbox module is not configured yet! Please configure it <a href="%link%"><strong>here</strong></a>.' => 'Modul Dropbox ještě není nastavení. Prosím, nastavte jej <a href="%link%"><strong>zde</strong></a>.',
);
