<?php
return array (
  'Access denied!' => 'Tillträde nekas!',
);
