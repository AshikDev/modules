<?php
return array (
  'Invalid file' => '',
  'Message' => 'Medelande',
);
