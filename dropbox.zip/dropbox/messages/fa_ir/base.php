<?php
return array (
  'Add Dropbox files' => 'اضافه كردن فايل از دراپباكس',
);
