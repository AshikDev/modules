<?php
return array (
  'Invalid file' => '',
  'Message' => 'メッセージ',
);
