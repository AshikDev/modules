<?php
return array (
  'Access denied!' => 'アクセスが拒否されました！',
);
