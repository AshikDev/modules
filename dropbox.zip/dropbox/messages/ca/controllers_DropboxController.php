<?php
return array (
  'Access denied!' => 'Accés denegat!',
);
