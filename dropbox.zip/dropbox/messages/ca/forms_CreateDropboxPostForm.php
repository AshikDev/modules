<?php
return array (
  'Invalid file' => '',
  'Message' => 'Missatge',
);
