<?php
return array (
  'Dropbox post' => 'Contribution Dropbox',
);
