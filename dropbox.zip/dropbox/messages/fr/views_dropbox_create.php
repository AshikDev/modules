<?php
return array (
  'Describe your files' => 'Décrivez vos fichiers',
);
