<?php
return array (
  'Back to modules' => 'Retour aux modules',
  'Dropbox Module Configuration' => 'Configuration du module Dropbox',
  'Save' => 'Enregistrer',
  'The dropbox module needs active dropbox application created! Please go to this <a href="%link%" target="_blank"><strong>site</strong></a>, choose "Drop-ins app" and provide an app name to get your API key.' => 'Le module dropbox nécessite la création d\'une application dropbox active ! Merci de se rendre sur <a href="%link%" target="_blank"><strong>ce site</strong></a>, choisir "Drop-ins app" et fournir un nom d\'application pour obtenir votre clé API.',
);
