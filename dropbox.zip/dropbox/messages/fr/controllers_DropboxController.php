<?php
return array (
  'Access denied!' => 'Accès refusé.',
);
