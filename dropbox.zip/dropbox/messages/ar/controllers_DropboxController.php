<?php
return array (
  'Access denied!' => 'ممنوع المرور!',
);
