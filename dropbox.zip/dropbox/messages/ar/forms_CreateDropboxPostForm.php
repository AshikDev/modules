<?php
return array (
  'Invalid file' => '',
  'Message' => 'الرسالة',
);
