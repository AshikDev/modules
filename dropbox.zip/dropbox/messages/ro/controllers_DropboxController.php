<?php
return array (
  'Access denied!' => 'Acces respins!',
);
