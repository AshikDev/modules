<?php
return array (
  'Invalid file' => '',
  'Message' => 'Mesaj',
);
