<?php
return array (
  'Show warning on posting' => 'Pokaż ostrzeżenie przy publikacji',
);
