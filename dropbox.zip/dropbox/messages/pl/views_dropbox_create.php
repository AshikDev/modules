<?php
return array (
  'Describe your files' => 'Opis dla Twoich plików',
);
