<?php
return array (
  'Dropbox post' => 'Wpis typu Dropbox',
);
