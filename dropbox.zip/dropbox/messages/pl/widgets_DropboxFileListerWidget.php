<?php
return array (
  '<strong>Attention!</strong> You are sharing private files' => '<strong>Uwaga!</strong> Udostępniasz prywatne pliki',
  'Cancel' => 'Anuluj',
  'Do not show this warning in future' => 'Nie pokazuj tego komunikatu w przyszłości',
  'The files you want to share are private. In order to share files in your space we have generated a shared link. Everyone with the link can see the file.<br/>Are you sure you want to share?' => 'Pliki, którymi chcesz się podzielić są prywatne. Aby się nimi podzielić w strefach, wygenerowaliśmy odnośnik udostępniania. Każda osoba z odnośnikiem może zobaczyć plik.<br/>Czy na pewno chcesz udostępnić? ',
  'Yes, I\'m sure' => 'Tak, jestem pewien.',
);
