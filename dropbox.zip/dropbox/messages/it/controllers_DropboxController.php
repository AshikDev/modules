<?php
return array (
  'Access denied!' => 'Accesso negato!',
);
