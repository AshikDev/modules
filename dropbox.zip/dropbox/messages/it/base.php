<?php
return array (
  'Add Dropbox files' => 'Aggiungi file da Dropbox',
);
