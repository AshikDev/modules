<?php
return array (
  '<strong>Dropbox</strong> settings' => 'Impostazioni <strong>Dropbox</strong>',
  'Submit' => 'Invia',
);
