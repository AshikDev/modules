<?php
return array (
  'Invalid file' => 'File non valido',
  'Message' => 'Messaggio',
);
