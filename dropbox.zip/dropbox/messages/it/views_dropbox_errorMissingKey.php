<?php
return array (
  'Sorry, the Dropbox module is not configured yet! Please get in touch with the administrator.' => 'Il modulo Dropbox non è ancora configurato. contatta l\'amministratore per aiutarti.',
  'The Dropbox module is not configured yet! Please configure it <a href="%link%"><strong>here</strong></a>.' => 'Il modulo Dropbox non è ancora configurato! Configuralo <a href="%link%"><strong>qui</strong></a>.
',
);
