<?php
return array (
  'Describe your files' => 'Descrivi i tuoi file',
);
