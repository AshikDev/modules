<?php
return array (
  'Show warning on posting' => 'Mostra avvisi quando crei post',
);
