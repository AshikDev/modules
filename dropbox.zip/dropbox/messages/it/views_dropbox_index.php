<?php
return array (
  'Describe your files' => 'Descrivi i tuoi file',
  'Select files from dropbox' => 'Scegli file da Dropbox',
  'Submit' => 'Invia',
);
