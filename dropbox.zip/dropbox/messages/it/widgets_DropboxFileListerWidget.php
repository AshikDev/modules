<?php
return array (
  '<strong>Attention!</strong> You are sharing private files' => '<strong>Attenzione!</strong> Stai condividendo file privati.',
  'Cancel' => 'Annulla',
  'Do not show this warning in future' => 'Non mostrare ulteriori avvisi in futuro',
  'The files you want to share are private. In order to share files in your space we have generated a shared link. Everyone with the link can see the file.<br/>Are you sure you want to share?' => 'Il file che vuoi condividere è privato. Per condividere i file nel tuo spazio abbiamo generato un link condiviso. Chiunque potrà vedere questo file. <br/>Sei sicuro di condividere?',
  'Yes, I\'m sure' => 'Sì, sono sicuro',
);
