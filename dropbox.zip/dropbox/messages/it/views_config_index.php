<?php
return array (
  'Back to modules' => 'Indietro ai moduli',
  'Dropbox Module Configuration' => 'Configurazione modulo Dropbox',
  'Save' => 'Salva',
  'The dropbox module needs active dropbox application created! Please go to this <a href="%link%" target="_blank"><strong>site</strong></a>, choose "Drop-ins app" and provide an app name to get your API key.' => 'Il modulo dropbox richiede un\'applicazione Dropbox attiva creata! Vai a questo  <a href="%link%" target="_blank"><strong>link</strong></a>, Scegli "Drop-ins app" ed inserisci un nome per l\'applicazione per ottenere la tua Api key.',
);
