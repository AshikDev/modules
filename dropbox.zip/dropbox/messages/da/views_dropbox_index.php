<?php
return array (
  'Describe your files' => 'Beskriv dine filer',
  'Select files from dropbox' => 'Vælg filer fra dropbox',
  'Submit' => 'Indsend',
);
