<?php
return array (
  'Invalid file' => 'Ugyldig fil',
  'Message' => 'Besked',
);
