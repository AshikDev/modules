<?php
return array (
  '<strong>Attention!</strong> You are sharing private files' => '<strong>Advarsel!</strong> Du deler private filer',
  'Cancel' => 'Afbryd',
  'Do not show this warning in future' => 'Vis ikke denne advarsel fremover',
  'The files you want to share are private. In order to share files in your space we have generated a shared link. Everyone with the link can see the file.<br/>Are you sure you want to share?' => 'Filer som du vil dele er private. For at dele filerne på din side så har har vi lavet et delt link. Alle med dette link kan se filen.<br/> Er du sikker på du vil dele?',
  'Yes, I\'m sure' => 'Ja, jeg er sikker',
);
