<?php
return array (
  'Access denied!' => 'Adgang nægtet!',
);
