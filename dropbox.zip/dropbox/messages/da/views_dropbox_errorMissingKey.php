<?php
return array (
  'Sorry, the Dropbox module is not configured yet! Please get in touch with the administrator.' => 'Beklager, Dropbox modulet er ikke konfigureret endnu! Venligst kontakt administratoren.',
  'The Dropbox module is not configured yet! Please configure it <a href="%link%"><strong>here</strong></a>.' => 'Dropbox modulet er ikke konfigureret endnu! Venligst konfigurer det <a href="%link%"><strong>her</strong></a>.',
);
