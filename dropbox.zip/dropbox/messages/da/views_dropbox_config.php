<?php
return array (
  '<strong>Dropbox</strong> settings' => '<strong>Dropbox</strong> indstillinger',
  'Submit' => 'Indsend',
);
