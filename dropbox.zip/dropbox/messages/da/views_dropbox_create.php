<?php
return array (
  'Describe your files' => 'Beskriv dine filer',
);
