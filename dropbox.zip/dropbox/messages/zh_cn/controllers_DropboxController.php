<?php
return array (
  'Access denied!' => '禁止访问',
);
