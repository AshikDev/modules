<?php
return array (
  '<strong>Dropbox</strong> settings' => '',
  'Submit' => '提交',
);
