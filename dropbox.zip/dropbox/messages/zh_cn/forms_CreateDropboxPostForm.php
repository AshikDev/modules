<?php
return array (
  'Invalid file' => '',
  'Message' => '消息',
);
