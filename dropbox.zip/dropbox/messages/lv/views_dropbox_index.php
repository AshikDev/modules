<?php
return array (
  'Describe your files' => '',
  'Select files from dropbox' => '',
  'Submit' => 'Iesniegt',
);
