<?php
return array (
  '<strong>Attention!</strong> You are sharing private files' => '',
  'Cancel' => 'Atcelt',
  'Do not show this warning in future' => '',
  'The files you want to share are private. In order to share files in your space we have generated a shared link. Everyone with the link can see the file.<br/>Are you sure you want to share?' => '',
  'Yes, I\'m sure' => '',
);
