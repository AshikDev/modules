<?php
return array (
  'Access denied!' => 'Pieeja noraidīta!',
);
