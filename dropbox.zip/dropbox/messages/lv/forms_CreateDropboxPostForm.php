<?php
return array (
  'Invalid file' => '',
  'Message' => 'Ziņa',
);
