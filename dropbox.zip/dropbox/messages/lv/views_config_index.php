<?php
return array (
  'Back to modules' => 'Atpakaļ uz moduļiem',
  'Dropbox Module Configuration' => '',
  'Save' => 'Saglabāt',
  'The dropbox module needs active dropbox application created! Please go to this <a href="%link%" target="_blank"><strong>site</strong></a>, choose "Drop-ins app" and provide an app name to get your API key.' => '',
);
