<?php
return array (
  '<strong>Dropbox</strong> settings' => '',
  'Submit' => 'Iesniegt',
);
