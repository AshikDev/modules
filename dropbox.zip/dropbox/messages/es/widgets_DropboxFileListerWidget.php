<?php
return array (
  '<strong>Attention!</strong> You are sharing private files' => '<Strong> ¡Atención! </ Strong> Estás compartiendo archivos privados',
  'Cancel' => 'Cancelar',
  'Do not show this warning in future' => 'No mostrar esta advertencia en el futuro',
  'The files you want to share are private. In order to share files in your space we have generated a shared link. Everyone with the link can see the file.<br/>Are you sure you want to share?' => 'Los archivos que deseas compartir son privados. Con el fin de compartir archivos en tu espacio hemos generado un enlace compartido. Todos los usuarios con el enlace pueden ver el archivo. <br/> ¿Seguro que quieres compartir?',
  'Yes, I\'m sure' => 'Sí, estoy seguro',
);
