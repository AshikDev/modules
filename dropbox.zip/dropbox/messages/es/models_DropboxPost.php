<?php
return array (
  'Dropbox post' => 'Publicación de Dropbox',
);
