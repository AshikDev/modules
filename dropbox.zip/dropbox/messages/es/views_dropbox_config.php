<?php
return array (
  '<strong>Dropbox</strong> settings' => 'Configuración de <strong>Dropbox</strong>',
  'Submit' => 'Enviar',
);
