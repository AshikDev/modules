<?php
return array (
  'Invalid file' => 'Archivo inválido',
  'Message' => 'Mensaje',
);
