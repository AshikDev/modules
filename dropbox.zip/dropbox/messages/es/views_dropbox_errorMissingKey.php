<?php
return array (
  'Sorry, the Dropbox module is not configured yet! Please get in touch with the administrator.' => 'Lo sentimos, el módulo de Dropbox no ha sido configurado aún. Por favor contacte al Administrador del sitio.',
  'The Dropbox module is not configured yet! Please configure it <a href="%link%"><strong>here</strong></a>.' => 'El módulo de Dropbox no ha sido configurado aún. Configúrelo <a href="%link%"><strong>aquí</strong></a>.',
);
