<?php
return array (
  'Describe your files' => 'Describe tus archivos',
  'Select files from dropbox' => 'Selecciona archivos de Dropbox',
  'Submit' => 'Enviar',
);
