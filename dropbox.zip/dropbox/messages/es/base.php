<?php
return array (
  'Add Dropbox files' => 'Añadir archivos de Dropbox',
);
