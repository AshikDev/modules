<?php
return array (
  'Describe your files' => 'Describe tus archivos',
);
