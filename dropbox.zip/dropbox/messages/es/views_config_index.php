<?php
return array (
  'Back to modules' => 'Regresar a Módulos',
  'Dropbox Module Configuration' => 'Ajustes del Módulo de Dropbox',
  'Save' => 'Guardar',
  'The dropbox module needs active dropbox application created! Please go to this <a href="%link%" target="_blank"><strong>site</strong></a>, choose "Drop-ins app" and provide an app name to get your API key.' => 'El módulo Dropbox necesita la aplicación Dropbox activa. Acceda a este <a href="%link%" target="_blank"> <strong> sitio </ strong> </a>, elija "Aplicación de Drop-ins" y proporcione un nombre de aplicación para obtener su clave de API.',
);
