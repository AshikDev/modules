<?php
return array (
  'Access denied!' => '¡Acceso denegado!',
);
