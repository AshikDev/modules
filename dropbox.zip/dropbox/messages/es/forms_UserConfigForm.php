<?php
return array (
  'Show warning on posting' => 'Mostrar advertencia en la publicación',
);
