<?php
return array (
  'Sorry, the Dropbox module is not configured yet! Please get in touch with the administrator.' => 'Žao nam je, Dropbox modul još nije konfiguriran! Molimo da kontaktirate administratora.',
  'The Dropbox module is not configured yet! Please configure it <a href="%link%"><strong>here</strong></a>.' => 'Dropbox modul još nije konfiguriran! Molimo konfigurirajte <a href="%link%"><strong>ovdje</strong></a>.',
);
