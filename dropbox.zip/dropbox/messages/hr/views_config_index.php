<?php
return array (
  'Back to modules' => 'Povratak na module',
  'Dropbox Module Configuration' => 'Dropbox konfiguracija modula',
  'Save' => 'Spremi',
  'The dropbox module needs active dropbox application created! Please go to this <a href="%link%" target="_blank"><strong>site</strong></a>, choose "Drop-ins app" and provide an app name to get your API key.' => 'Dropbox modul treba aktivnu dropbox aplikaciju! Molimo idite na <a href="%link%" target="_blank"><strong>site</strong></a>, odaberite "Drop-ins app" i unesite ime aplikacije kako bi dobili željeni API ključ.',
);
