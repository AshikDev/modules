<?php
return array (
  'Invalid file' => 'Neodgovarajuća datoteka',
  'Message' => 'Poruka',
);
