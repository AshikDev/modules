<?php
return array (
  'Describe your files' => 'Opišite vaše datoteke',
  'Select files from dropbox' => 'Odaberite datoteke sa dropbox-a',
  'Submit' => 'Potvrdi',
);
