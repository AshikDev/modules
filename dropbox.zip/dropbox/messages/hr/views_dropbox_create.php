<?php
return array (
  'Describe your files' => 'Opišite vaše datoteke',
);
