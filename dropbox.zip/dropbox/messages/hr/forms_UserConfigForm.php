<?php
return array (
  'Show warning on posting' => 'Prikaži upozorenje o objavljivanju',
);
