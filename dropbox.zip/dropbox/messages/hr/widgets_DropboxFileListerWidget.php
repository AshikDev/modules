<?php
return array (
  '<strong>Attention!</strong> You are sharing private files' => '<strong>Upozorenje!</strong> Dijelite privatne datoteke',
  'Cancel' => 'Poništi',
  'Do not show this warning in future' => 'Više ne prikazuj ovo upozorenje',
  'The files you want to share are private. In order to share files in your space we have generated a shared link. Everyone with the link can see the file.<br/>Are you sure you want to share?' => 'Datoteke koje želite podijeliti spadaju pod privatne. Kako bi podijelili datoteke u vašem prostoru generirana je poveznica (link) za dijeljenje. Svi s poveznicom (link-om) mogu vidjeti datoteku. <br/>Jeste li sigurni da želite podijeliti?',
  'Yes, I\'m sure' => 'Da, siguran sam',
);
