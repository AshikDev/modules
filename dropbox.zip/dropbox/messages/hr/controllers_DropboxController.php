<?php
return array (
  'Access denied!' => 'Pristup odbijen!',
);
