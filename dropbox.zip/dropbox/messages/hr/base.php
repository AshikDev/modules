<?php
return array (
  'Add Dropbox files' => 'Dodaj Dropbox datoteke',
);
