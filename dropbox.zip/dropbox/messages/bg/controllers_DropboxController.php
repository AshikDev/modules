<?php
return array (
  'Access denied!' => 'Достъп отказан!',
);
