<?php
return array (
  'Describe your files' => 'Beschrijving uw bestanden',
);
