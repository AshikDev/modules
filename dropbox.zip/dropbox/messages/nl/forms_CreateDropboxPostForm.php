<?php
return array (
  'Invalid file' => 'Ongeldig bestand',
  'Message' => 'Boodschap',
);
