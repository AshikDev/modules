<?php
return array (
  'Show warning on posting' => 'Toon meldingen bij posting',
);
