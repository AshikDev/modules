<?php
return array (
  'Add Dropbox files' => 'Voeg Dropbox bestanden toe.',
);
