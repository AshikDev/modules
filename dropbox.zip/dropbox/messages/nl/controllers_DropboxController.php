<?php
return array (
  'Access denied!' => 'Toegang geweigerd!',
);
