<?php
return array (
  'Describe your files' => 'Beschrijf uw bestanden',
  'Select files from dropbox' => 'Kies bestanden in de Dropbox',
  'Submit' => 'Verzend',
);
