<?php
return array (
  '<strong>Attention!</strong> You are sharing private files' => '<strong> Let op! </ strong> U deelt persoonlijke bestanden.',
  'Cancel' => 'Annuleer',
  'Do not show this warning in future' => 'Deze waarschuwing in de toekomst niet te laten zien.',
  'The files you want to share are private. In order to share files in your space we have generated a shared link. Everyone with the link can see the file.<br/>Are you sure you want to share?' => 'De bestanden die u wilt delen zijn privé. Om bestanden in uw ruimte te delen hebben we een gedeelde koppeling gegenereerd. Iedereen met de link kan het bestand te zien. <br/> Weet u zeker dat u de bestanden wilt delen?',
  'Yes, I\'m sure' => 'Ja, ik weet het zeker.',
);
