<?php
return array (
  'Back to modules' => 'Terug naar modules',
  'Dropbox Module Configuration' => 'Dropbox module instellingen',
  'Save' => 'Bewaar',
  'The dropbox module needs active dropbox application created! Please go to this <a href="%link%" target="_blank"><strong>site</strong></a>, choose "Drop-ins app" and provide an app name to get your API key.' => 'De dropbox module moet  actief in de dropbox applicatie worden gemaakt! Ga naar deze <a href="%link%" target="_blank"> <strong> webpagina </ strong> </a>, kies \'Drop-ins app "en koppel uw API-sleutel aan een app naam .',
);
