<?php
return array (
  'Describe your files' => 'Dosya açıklaması',
);
