<?php
return array (
  'Access denied!' => 'Erişim reddedildi!',
);
