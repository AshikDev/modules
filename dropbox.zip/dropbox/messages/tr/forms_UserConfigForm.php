<?php
return array (
  'Show warning on posting' => 'Mesajla ilgili uyarı göster',
);
