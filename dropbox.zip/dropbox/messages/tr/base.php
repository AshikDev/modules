<?php
return array (
  'Add Dropbox files' => 'Dropbox\'tan dosya ekle',
);
