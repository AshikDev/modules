<?php
return array (
  'Sorry, the Dropbox module is not configured yet! Please get in touch with the administrator.' => 'Üzgünüz, Dropbox modülü henüz yapılandırılmamış! Lütfen yönetici ile iletişime geçin.',
  'The Dropbox module is not configured yet! Please configure it <a href="%link%"><strong>here</strong></a>.' => 'Dropbox modülü henüz yapılandırılmamış! Lütfen <a href="%25link%25"><strong>buradan</strong></a> yapılandırın.',
);
