<?php
return array (
  'Back to modules' => 'Modüllere dön',
  'Dropbox Module Configuration' => 'Dropbox Modül Yapılandırması',
  'Save' => 'Kaydet',
  'The dropbox module needs active dropbox application created! Please go to this <a href="%link%" target="_blank"><strong>site</strong></a>, choose "Drop-ins app" and provide an app name to get your API key.' => 'Dropbox modülü, oluşturulan etkin dropbox uygulamasına ihtiyaç duyar! Lütfen bu <a href="%25link%25"><strong>site</strong></a> adresine gidin, "Drop-ins uygulaması" nı seçin ve API anahtarınızı almak için bir uygulama adı girin.',
);
