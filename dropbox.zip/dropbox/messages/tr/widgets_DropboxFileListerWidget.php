<?php
return array (
  '<strong>Attention!</strong> You are sharing private files' => '<strong>Dikkat!</strong> Özel dosyaları paylaşıyorsunuz',
  'Cancel' => 'İptal',
  'Do not show this warning in future' => 'Bu uyarıyı ileride gösterme',
  'The files you want to share are private. In order to share files in your space we have generated a shared link. Everyone with the link can see the file.<br/>Are you sure you want to share?' => 'Paylaşmak istediğiniz dosyalar gizlidir. Mekanınızda dosyaları paylaşmak için bir bağlantı oluşturduk. Bağlantıya sahip olan herkes dosyayı görebilir. <br /> Paylaşmak istediğinizden emin misiniz?',
  'Yes, I\'m sure' => 'Evet eminim',
);
