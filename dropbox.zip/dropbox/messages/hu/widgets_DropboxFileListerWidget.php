<?php
return array (
  '<strong>Attention!</strong> You are sharing private files' => '<strong>Figyelem!</strong> Privát fájlokat készülsz megosztani',
  'Cancel' => 'Mégsem',
  'Do not show this warning in future' => 'A jövőben ne mutassa ezt a figyelmeztetést',
  'The files you want to share are private. In order to share files in your space we have generated a shared link. Everyone with the link can see the file.<br/>Are you sure you want to share?' => 'A megosztani kívánt fájlok privát jellegűek. A közösségeden belüli fájlok megosztásához megosztott linket hoztunk létre. Mindenki láthatja a fájlt, aki rendelkezik a linkkel. <br /> Biztosan meg akarod osztani?',
  'Yes, I\'m sure' => 'Igen, biztos vagyok benne',
);
