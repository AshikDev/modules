<?php
return array (
  'Invalid file' => 'Érvénytelen fájl',
  'Message' => 'Üzenet',
);
