<?php
return array (
  'Access denied!' => 'Nincs hozzáférésed!',
);
