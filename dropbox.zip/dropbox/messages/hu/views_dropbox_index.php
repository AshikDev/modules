<?php
return array (
  'Describe your files' => 'Írd le, hogy milyenek a fájljaid.',
  'Select files from dropbox' => 'Válaszd ki a fájlokat a dropbox-ból',
  'Submit' => 'Küldés',
);
