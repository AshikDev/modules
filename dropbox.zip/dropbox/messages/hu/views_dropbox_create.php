<?php
return array (
  'Describe your files' => 'Írd le, hogy milyenek a fájljaid.',
);
