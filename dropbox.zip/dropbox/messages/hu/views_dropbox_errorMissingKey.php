<?php
return array (
  'Sorry, the Dropbox module is not configured yet! Please get in touch with the administrator.' => 'Sajnáljuk, ez a Dropbox modul még nincs konfigurálva! Kérjük, lépj kapcsolatba a rendszergazdával.',
  'The Dropbox module is not configured yet! Please configure it <a href="%link%"><strong>here</strong></a>.' => 'Sajnáljuk, ez a Dropbox modul még nincs konfigurálva! Kérjük, konfiguráld <a href="%25link%25"><strong>itt</strong></a>.',
);
