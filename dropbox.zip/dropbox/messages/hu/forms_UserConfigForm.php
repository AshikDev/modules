<?php
return array (
  'Show warning on posting' => 'Bejegyzés közzétételekor figyelmeztessen',
);
