<?php
return array (
  'Add Dropbox files' => 'Dropbox fájlok hozzáadása',
);
