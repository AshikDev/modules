<?php
return array (
  'Dropbox post' => 'Dropbox bejegyzés',
);
