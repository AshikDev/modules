<?php
return array (
  'Back to modules' => 'Vissza a modulokhoz',
  'Dropbox Module Configuration' => 'Dropbox modul konfiguráció',
  'Save' => 'Mentés',
  'The dropbox module needs active dropbox application created! Please go to this <a href="%link%" target="_blank"><strong>site</strong></a>, choose "Drop-ins app" and provide an app name to get your API key.' => 'A dropbox modulhoz aktív dropbox applikációt kell létrehozni! Kérjük, látogass el ide <a href="%25link%25"><strong>site</strong></a>, majd válaszd a "Drop-ins app" opciót és adj meg egy app nevet, hogy megkapd  az API kulcsot.',
);
