<?php
return array (
  'Dropbox API Key' => 'Дропбокс API Key',
);
