<?php
return array (
  'Add Dropbox files' => 'Добавить файлы дропбокс',
);
