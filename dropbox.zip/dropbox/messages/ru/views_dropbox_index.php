<?php
return array (
  'Describe your files' => 'Опишите ваши файлы',
  'Select files from dropbox' => 'Выберите файлы из дропбокс',
  'Submit' => 'Принять',
);
