<?php

return [
    'Show warning on posting' => '',
];
