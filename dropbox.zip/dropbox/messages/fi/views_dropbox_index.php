<?php

return [
    'Describe your files' => '',
    'Select files from dropbox' => '',
    'Submit' => '',
];
