<?php

return [
    'Sorry, the Dropbox module is not configured yet! Please get in touch with the administrator.' => '',
    'The Dropbox module is not configured yet! Please configure it <a href="%link%"><strong>here</strong></a>.' => '',
];
