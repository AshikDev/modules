<?php

return [
    'Access denied!' => '',
];
