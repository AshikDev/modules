<?php

return [
    '<strong>Dropbox</strong> settings' => '',
    'Submit' => '',
];
